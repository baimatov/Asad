/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Mic, Shield, Brain, Target, Activity, 
  Check, ChevronRight, Play, AlertCircle, 
  RotateCcw, Volume2, VolumeX, Keyboard, 
  Send, HelpCircle, AlertTriangle, FileText, X
} from "lucide-react";
import { ExamStats, Message, VerdictResult } from "./types";
import asadAvatar from "./assets/images/regenerated_image_1783166529439.png";

export default function App() {
  // Navigation / screen state
  const [step, setStep] = useState<'start' | 'exam' | 'verdict'>('start');
  const [onboardingStep, setOnboardingStep] = useState<1 | 2>(1);
  
  // Input states
  const [topic, setTopic] = useState("");
  const [notes, setNotes] = useState("");
  const [micPermission, setMicPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [keyboardMode, setKeyboardMode] = useState(false);
  const [ttsMode, setTtsMode] = useState<'system' | 'gemini' | 'muted'>('gemini');
  const [apiError, setApiError] = useState<string | null>(null);
  
  // Exam session states
  const [sessionId, setSessionId] = useState("");
  const [activeQuestion, setActiveQuestion] = useState("");
  const [textAnswer, setTextAnswer] = useState("");
  const [transcript, setTranscript] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dialogueHistory, setDialogueHistory] = useState<Message[]>([]);
  
  // Real-time speech statistics
  const [stats, setStats] = useState<ExamStats>({
    pauses: 0,
    fillers: 0,
    confidence: 100,
    errors: 0
  });

  // Time tracking
  const [timerSeconds, setTimerSeconds] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Sound playback state & ref
  const [isAsadSpeaking, setIsAsadSpeaking] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Real-time microphone audio visualizer level
  const [audioLevel, setAudioLevel] = useState(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const javascriptNodeRef = useRef<ScriptProcessorNode | null>(null);

  // Speech Recognition ref
  const recognitionRef = useRef<any>(null);
  const silenceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSpeechTimeRef = useRef<number>(Date.now());
  const countedFillerWordsRef = useRef<Set<number>>(new Set());
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const autoSubmitAfterTranscribeRef = useRef<boolean>(false);

  // Final evaluation verdict
  const [verdict, setVerdict] = useState<VerdictResult | null>(null);
  const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);

  // Popular topics list
  const popularTopics = [
    "Математический анализ",
    "Линейная Алгебра",
    "Теория вероятностей",
    "Алгоритмы и структуры данных",
    "Физика. Механика"
  ];

  // List of common Russian filler words (слова-паразиты)
  const fillerWords = ["ну", "типа", "как бы", "короче", "ээ", "аа", "это самое", "в общем", "собственно", "так сказать"];

  // 1. Microphone equipment check
  const requestMicPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setMicPermission('granted');
      stream.getTracks().forEach(track => track.stop());
    } catch (err) {
      console.error("Mic check error:", err);
      setMicPermission('denied');
    }
  };

  // Check microphone status on step 2 onboarding
  useEffect(() => {
    if (onboardingStep === 2 && micPermission === 'prompt') {
      requestMicPermission();
    }
  }, [onboardingStep, micPermission]);

  // 2. Timer effect during exam
  useEffect(() => {
    if (step === 'exam') {
      timerRef.current = setInterval(() => {
        setTimerSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setTimerSeconds(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [step]);

  // Format timer seconds into MM:SS
  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 3. Audio volume analyzer for recording waveform
  useEffect(() => {
    if (!isRecording) {
      setAudioLevel(0);
      if (javascriptNodeRef.current) {
        try { javascriptNodeRef.current.disconnect(); } catch (e) {}
      }
      if (analyserRef.current) {
        try { analyserRef.current.disconnect(); } catch (e) {}
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
      return;
    }

    navigator.mediaDevices.getUserMedia({ audio: true })
      .then((stream) => {
        micStreamRef.current = stream;
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        const audioCtx = new AudioContextClass();
        audioContextRef.current = audioCtx;
        
        const analyser = audioCtx.createAnalyser();
        analyserRef.current = analyser;
        analyser.smoothingTimeConstant = 0.4;
        analyser.fftSize = 256;

        const source = audioCtx.createMediaStreamSource(stream);
        const scriptNode = audioCtx.createScriptProcessor(2048, 1, 1);
        javascriptNodeRef.current = scriptNode;

        source.connect(analyser);
        analyser.connect(scriptNode);
        scriptNode.connect(audioCtx.destination);

        scriptNode.onaudioprocess = () => {
          const array = new Uint8Array(analyser.frequencyBinCount);
          analyser.getByteFrequencyData(array);
          let values = 0;
          for (let i = 0; i < array.length; i++) {
            values += array[i];
          }
          const average = values / array.length;
          // Scale to a nice visual range
          setAudioLevel(Math.min(100, Math.round(average * 2.2)));
        };
      })
      .catch((err) => {
        console.error("Audio analyzer setup error:", err);
      });

    return () => {
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    };
  }, [isRecording]);

  // 4. TTS engine - Speech Synthesis or server Gemini TTS
  const speakAsad = async (text: string) => {
    // Cancel any ongoing playbacks
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
    }
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    
    if (ttsMode === 'muted') {
      setIsAsadSpeaking(false);
      return;
    }

    setIsAsadSpeaking(true);

    if (ttsMode === 'gemini') {
      try {
        const response = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        const data = await response.json();
        if (data.audio) {
          const audio = new Audio(data.audio);
          audioRef.current = audio;
          audio.onended = () => setIsAsadSpeaking(false);
          audio.onerror = () => {
            console.warn("Gemini TTS playback error, falling back to system TTS...");
            speakSystemTTS(text);
          };
          await audio.play();
        } else {
          speakSystemTTS(text);
        }
      } catch (err) {
        console.warn("Gemini TTS error, falling back to system speech synthesis:", err);
        speakSystemTTS(text);
      }
    } else {
      speakSystemTTS(text);
    }
  };

  const speakSystemTTS = (text: string) => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      setIsAsadSpeaking(false);
      return;
    }

    // Cancel any ongoing speech first to avoid overlapping or queuing
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ru-RU';
    utterance.rate = 1.05; // Slightly faster to sound crisp and decisive
    utterance.pitch = 0.85; // Lower pitch for mature male tone

    // Helper to find best Russian male voice, then any Russian voice
    const findVoice = (voiceList: SpeechSynthesisVoice[]) => {
      // Look for Russian Male voices (Pavel, Yuri, Male, etc.)
      const ruMale = voiceList.find(v => 
        v.lang.startsWith('ru') && 
        (v.name.toLowerCase().includes('male') || 
         v.name.toLowerCase().includes('pavel') || 
         v.name.toLowerCase().includes('yuri'))
      );
      if (ruMale) return ruMale;

      // Look for any Russian voice
      const ruAny = voiceList.find(v => v.lang.startsWith('ru'));
      if (ruAny) return ruAny;

      // Fallback to Google Russian or any voice with "russian" in name
      const ruName = voiceList.find(v => v.name.toLowerCase().includes('russian') || v.name.toLowerCase().includes('русский'));
      if (ruName) return ruName;

      return null;
    };

    const voices = window.speechSynthesis.getVoices();
    const voice = findVoice(voices);
    if (voice) {
      utterance.voice = voice;
    } else {
      // If voices are empty (can happen on first load), we register onvoiceschanged
      window.speechSynthesis.onvoiceschanged = () => {
        const updatedVoices = window.speechSynthesis.getVoices();
        const lazyVoice = findVoice(updatedVoices);
        if (lazyVoice) {
          utterance.voice = lazyVoice;
        }
      };
    }

    utterance.onend = () => setIsAsadSpeaking(false);
    utterance.onerror = () => setIsAsadSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Initialize Speech Recognition
  useEffect(() => {
    if (typeof window === "undefined") return;
    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognitionClass) {
      const rec = new SpeechRecognitionClass();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'ru-RU';

      rec.onresult = (event: any) => {
        let interimText = "";
        let final = "";
        for (let i = 0; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interimText += event.results[i][0].transcript;
          }
        }
        
        const fullTranscript = final + interimText;
        setTranscript(fullTranscript);
        lastSpeechTimeRef.current = Date.now();

        // Calculate fillers
        const words = fullTranscript.toLowerCase().split(/\s+/);
        let foundFillersCount = 0;
        words.forEach((word, idx) => {
          if (fillerWords.some(f => word.includes(f))) {
            if (!countedFillerWordsRef.current.has(idx)) {
              countedFillerWordsRef.current.add(idx);
              foundFillersCount++;
            }
          }
        });

        if (foundFillersCount > 0) {
          setStats(prev => {
            const nextFillers = prev.fillers + foundFillersCount;
            return {
              ...prev,
              fillers: nextFillers,
              confidence: Math.max(15, prev.confidence - (foundFillersCount * 4))
            };
          });
        }
      };

      rec.onerror = (e: any) => {
        console.error("Speech Recognition error:", e);
        setIsRecording(false);
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  // Silence checker for "паузы длинные" (gaps of silence)
  useEffect(() => {
    if (isRecording) {
      lastSpeechTimeRef.current = Date.now();
      silenceTimerRef.current = setInterval(() => {
        const elapsedSinceLastSpeech = Date.now() - lastSpeechTimeRef.current;
        if (elapsedSinceLastSpeech > 4500) { // If student keeps quiet for 4.5 seconds
          setStats(prev => {
            const nextPauses = prev.pauses + 1;
            return {
              ...prev,
              pauses: nextPauses,
              confidence: Math.max(15, prev.confidence - 8)
            };
          });
          // Reset speech time so we don't trigger again immediately
          lastSpeechTimeRef.current = Date.now();
        }
      }, 1000);
    } else {
      if (silenceTimerRef.current) clearInterval(silenceTimerRef.current);
    }
    return () => {
      if (silenceTimerRef.current) clearInterval(silenceTimerRef.current);
    };
  }, [isRecording]);

  // Helper to start MediaRecorder recording
  const startRecordingStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      audioChunksRef.current = [];
      
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        if (audioBlob.size < 1000) {
          if (autoSubmitAfterTranscribeRef.current) {
            autoSubmitAfterTranscribeRef.current = false;
            alert("Запись слишком короткая или пустая. Пожалуйста, попробуйте еще раз.");
          }
          return;
        }
        
        setIsSubmitting(true);
        // Convert Blob to Base64
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          try {
            const base64Audio = (reader.result as string).split(',')[1];
            const response = await fetch("/api/transcribe", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ audio: base64Audio, mimeType: 'audio/webm' })
            });
            const data = await response.json();
            if (data.text) {
              setTranscript(data.text);
              if (autoSubmitAfterTranscribeRef.current) {
                autoSubmitAfterTranscribeRef.current = false;
                submitAnswer(data.text);
              }
            } else {
              if (autoSubmitAfterTranscribeRef.current) {
                autoSubmitAfterTranscribeRef.current = false;
                alert("Не удалось распознать речь. Попробуйте ввести ответ текстом или сказать четче.");
              }
            }
          } catch (err) {
            console.error("Transcription failed:", err);
            if (autoSubmitAfterTranscribeRef.current) {
              autoSubmitAfterTranscribeRef.current = false;
              alert("Ошибка при распознавании аудио. Пожалуйста, попробуйте еще раз или перейдите на текстовый режим.");
            }
          } finally {
            setIsSubmitting(false);
          }
        };
      };
      
      mediaRecorder.start(200);
    } catch (err) {
      console.error("Error starting MediaRecorder:", err);
    }
  };

  // Helper to stop MediaRecorder recording
  const stopRecordingStream = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        console.warn("Stop mediaRecorder failed:", e);
      }
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
    }
  };

  // Handle Speech Toggle
  const toggleRecording = async () => {
    if (isRecording) {
      // 1. Stop SpeechRecognition (if active)
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
      // 2. Stop MediaRecorder
      stopRecordingStream();
      setIsRecording(false);
    } else {
      setTranscript("");
      countedFillerWordsRef.current.clear();
      setIsRecording(true);
      
      // 1. Start standard speech recognition as an option/realtime feedback
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {
          console.warn("Recognition start failed:", e);
        }
      }
      
      // 2. Start MediaRecorder for guaranteed server-side transcription
      await startRecordingStream();
    }
  };

  // Helper to stop recording and submit once transcribed
  const stopAndSubmitVoice = () => {
    autoSubmitAfterTranscribeRef.current = true;
    if (isRecording) {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
      stopRecordingStream();
      setIsRecording(false);
    }
  };

  // 5. Start Exam session calling Express Backend
  const handleStartExam = async () => {
    if (!topic.trim()) {
      alert("Пожалуйста, введите тему или выберите одну из популярных.");
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch("/api/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, notes }),
      });
      const data = await response.json();
      if (data.sessionId) {
        setSessionId(data.sessionId);
        setActiveQuestion(data.question);
        setDialogueHistory([{ role: 'assistant', content: data.question }]);
        setStep('exam');
        speakAsad(data.question);
      } else {
        setApiError(data.error || "Не удалось запустить экзаменатора.");
      }
    } catch (err) {
      console.error("Start exam error:", err);
      setApiError("Ошибка подключения к серверу или превышена квота запросов к ИИ. Убедитесь, что сервер запущен, или попробуйте позже.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // 6. Submit Answer (Voice/Text)
  const submitAnswer = async (answerText: string) => {
    const finalAnswer = answerText.trim();
    if (!finalAnswer) return;

    if (isRecording) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          console.warn("recognition stop failed:", e);
        }
      }
      stopRecordingStream();
      setIsRecording(false);
    }

    setIsSubmitting(true);
    // Append answer to history
    setDialogueHistory(prev => [...prev, { role: 'user', content: finalAnswer }]);
    setTextAnswer("");
    setTranscript("");

    try {
      const response = await fetch("/api/respond", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          transcript: finalAnswer,
          stats: {
            pauses: stats.pauses,
            fillers: stats.fillers
          }
        }),
      });
      const data = await response.json();
      if (data.question) {
        setActiveQuestion(data.question);
        setDialogueHistory(prev => [...prev, { role: 'assistant', content: data.question }]);
        
        // Update stats returned from server evaluation
        setStats({
          pauses: data.stats.pauses,
          fillers: data.stats.fillers,
          errors: data.stats.errors,
          confidence: data.stats.confidence
        });

        speakAsad(data.question);
      } else {
        setApiError(data.error || "Ошибка получения ответа.");
      }
    } catch (err) {
      console.error("Submit answer error:", err);
      setApiError("Ошибка соединения с сервером при отправке ответа. Пожалуйста, попробуйте еще раз.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // 7. Finish exam and get verdict
  const handleFinishExam = async () => {
    setIsSubmitting(true);
    if (audioRef.current) audioRef.current.pause();
    if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
    
    try {
      const response = await fetch("/api/finish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      });
      const data = await response.json();
      if (data.error) {
        setApiError(data.error);
      } else {
        setVerdict(data);
        setStep('verdict');
      }
    } catch (err) {
      console.error("Finish exam error:", err);
      setApiError("Ошибка при получении вердикта. Пожалуйста, попробуйте еще раз.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Reset exam state to start over
  const restartExam = () => {
    setStep('start');
    setOnboardingStep(1);
    setTopic("");
    setSessionId("");
    setActiveQuestion("");
    setDialogueHistory([]);
    setVerdict(null);
    setStats({
      pauses: 0,
      fillers: 0,
      confidence: 100,
      errors: 0
    });
  };

  return (
    <div className="min-h-screen bg-[#07080d] text-gray-100 flex flex-col justify-between selection:bg-red-600/30 selection:text-red-200">
      
      {/* HEADER BAR */}
      <header className="border-b border-gray-900 bg-[#0a0c16]/80 backdrop-blur px-6 py-4 flex justify-between items-center z-10 sticky top-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-700/50 flex items-center justify-center font-mono text-lg font-black text-red-500 glow-red">А</div>
          <div>
            <div className="font-black tracking-wider text-sm flex items-center gap-2">
              АСАД <span className="text-red-500">ЭКЗАМЕНАТОР</span>
            </div>
            <div className="text-[10px] text-gray-500 font-mono">STRICT INTERROGATION ENG v1.2</div>
          </div>
        </div>

        {/* TOP SYSTEM SETTINGS (TTS Modes) */}
        <div className="flex items-center gap-4">
          <div className="flex bg-[#111424] border border-gray-800 rounded-lg p-1 text-xs font-mono">
            <button 
              onClick={() => setTtsMode('system')} 
              className={`px-2.5 py-1 rounded-md transition-all ${ttsMode === 'system' ? 'bg-red-950/60 text-red-400 font-bold border border-red-800/60 shadow-[0_0_12px_rgba(239,68,68,0.15)]' : 'border border-transparent text-gray-400 hover:text-white'}`}
              title="Использовать системный синтезатор речи (высокая скорость)"
            >
              Системный
            </button>
            <button 
              onClick={() => setTtsMode('gemini')} 
              className={`px-2.5 py-1 rounded-md transition-all ${ttsMode === 'gemini' ? 'bg-red-950/60 text-red-500 font-bold border border-red-800/60 shadow-[0_0_12px_rgba(239,68,68,0.15)]' : 'border border-transparent text-gray-400 hover:text-white'}`}
              title="Использовать нейросетевой ИИ голос Gemini (высокое качество)"
            >
              ИИ Голос
            </button>
            <button 
              onClick={() => setTtsMode('muted')} 
              className={`p-1 px-2.5 rounded-md transition ${ttsMode === 'muted' ? 'bg-gray-800 text-gray-300' : 'text-gray-400 hover:text-white'}`}
              title="Выключить озвучку"
            >
              <VolumeX className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* MAIN LAYOUT CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col justify-center">
        
        <AnimatePresence mode="wait">
          
          {/* STEP START: Setup & Equipment Check */}
          {step === 'start' && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full"
            >
              
              {/* Left Column: Avatar & Brand Accent Card */}
              <div className="lg:col-span-5 flex flex-col justify-between bg-[#0e101b] border border-gray-900 rounded-3xl p-6 md:p-8 relative overflow-hidden group">
                {/* Background artistic glow */}
                <div className="absolute -top-40 -left-40 w-80 h-80 rounded-full bg-red-950/20 blur-3xl group-hover:bg-red-950/30 transition-all duration-700 pointer-events-none" />
                
                <div className="relative z-10">
                  <span className="text-red-500 font-bold tracking-widest text-[10px] uppercase bg-red-950/30 px-3 py-1.5 rounded-full border border-red-900/30">
                    ИИ-СИМУЛЯТОР УСТНОГО ЭКЗАМЕНА
                  </span>
                  <h1 className="text-5xl md:text-6xl font-black tracking-tighter mt-4 leading-none">
                    АСАД<br/>
                    <span className="text-red-600 glow-red">ЭКЗАМЕНАТОР</span>
                  </h1>
                  <p className="text-gray-400 text-sm mt-4 leading-relaxed max-w-sm">
                    Голосовой ИИ-симулятор строгого устного экзамена. Жесткий спарринг перед сессией. Найди логические дыры в знаниях и защити свой балл.
                  </p>

                  <div className="flex flex-wrap gap-2.5 mt-6">
                    <span className="bg-[#141727] text-gray-300 text-xs px-3.5 py-2 rounded-xl border border-gray-800/80 flex items-center gap-1.5 font-mono">
                      <Mic className="w-3.5 h-3.5 text-red-500" /> Только голос
                    </span>
                    <span className="bg-[#141727] text-gray-300 text-xs px-3.5 py-2 rounded-xl border border-gray-800/80 flex items-center gap-1.5 font-mono">
                      <Shield className="w-3.5 h-3.5 text-red-500" /> Без регистрации
                    </span>
                  </div>
                </div>

                {/* Examiner Avatar Frame */}
                <div className="mt-8 relative z-10 flex flex-col items-center">
                  <div className="relative w-44 h-44 md:w-52 md:h-52 rounded-3xl overflow-hidden border-2 border-red-900/30 hover:border-red-600/50 transition-all duration-300 glow-red">
                    <img 
                      src={asadAvatar} 
                      alt="Asad Examiner Portrait" 
                      className="w-full h-full object-cover scale-105 hover:scale-110 transition duration-500"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Speech box overlay */}
                    <div className="absolute bottom-2 left-2 right-2 bg-[#090b14]/90 backdrop-blur-sm border border-gray-800 rounded-xl p-2.5 text-center">
                      <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Асад Экзаменатор</div>
                      <div className="text-xs font-semibold text-white mt-0.5">Готов к допросу по теме?</div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 relative z-10">
                  <button 
                    onClick={() => {
                      if (topic.trim()) {
                        handleStartExam();
                      } else {
                        setOnboardingStep(1);
                        document.getElementById("topic-input")?.focus();
                      }
                    }}
                    className="w-full bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 text-white font-bold py-4 rounded-2xl shadow-lg hover:shadow-red-900/30 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-current" /> НАЧАТЬ ЭКЗАМЕН
                  </button>
                </div>
              </div>

              {/* Steps Onboarding Container */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                
                {/* STEP 1 Card: Select Topic */}
                <div className={`bg-[#0e101b] border rounded-3xl p-6 md:p-8 transition-all duration-300 ${onboardingStep === 1 ? 'border-red-600/30' : 'border-gray-900 opacity-60'}`}>
                  <div className="flex justify-between items-center border-b border-gray-900/50 pb-4 mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-700/50 flex items-center justify-center text-sm font-mono font-bold text-red-500 shadow-[0_0_10px_rgba(239,68,68,0.1)]">1</div>
                      <div>
                        <div className="text-[10px] text-red-500 font-bold uppercase tracking-wider">ШАГ 1 ИЗ 2</div>
                        <h2 className="text-2xl font-bold text-white tracking-tight">Выбери тему</h2>
                      </div>
                    </div>
                    {onboardingStep > 1 && (
                      <div className="w-6 h-6 rounded-full bg-red-900/20 border border-red-500/50 flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 text-red-400" />
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs text-gray-400 font-mono mb-2">Введите тему или название билета</label>
                      <input 
                        type="text" 
                        id="topic-input"
                        placeholder="Например: Интегралы в математическом анализе" 
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        className="w-full bg-[#07080d] border border-gray-800 rounded-2xl px-5 py-5 text-base focus:outline-none focus:border-red-500 text-gray-100 placeholder-gray-600 transition"
                      />
                    </div>

                    <div className="space-y-2">
                      <span className="text-xs text-gray-500 font-mono uppercase block tracking-wider">ИЛИ ВЫБЕРИТЕ ИЗ ПОПУЛЯРНЫХ ТЕМ:</span>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {popularTopics.map((pt, i) => (
                          <button 
                            key={i}
                            onClick={() => {
                              setTopic(pt);
                              setOnboardingStep(2);
                            }}
                            className={`text-left text-sm bg-[#121526] hover:bg-red-950/20 hover:border-red-900/40 border rounded-2xl px-5 py-4 text-gray-300 hover:text-white transition flex items-center justify-between ${topic === pt ? 'border-red-600/40 bg-red-950/10 text-red-400' : 'border-gray-900'}`}
                          >
                            <span className="font-medium">{pt}</span>
                            <ChevronRight className="w-4 h-4 text-gray-600" />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Conspectus Upload / Paste Option */}
                    <div className="border-t border-gray-900/50 pt-4 mt-4">
                      <div className="flex justify-between items-center mb-2">
                        <label className="block text-xs text-gray-400 font-mono">
                          Загрузить конспект или лекцию (необязательно)
                        </label>
                        <span className="text-[10px] text-red-500 font-mono font-bold bg-red-950/25 border border-red-900/30 px-2 py-0.5 rounded-full">
                          СТРОГО ПО КОНСПЕКТУ
                        </span>
                      </div>
                      
                      <textarea 
                        rows={4} 
                        placeholder="Вставьте сюда текст вашего конспекта или шпаргалки по теме, чтобы Асад спрашивал строго по вашему материалу..." 
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="w-full bg-[#07080d] border border-gray-800 rounded-xl px-4 py-3 text-xs focus:outline-none focus:border-red-500 text-gray-200 placeholder-gray-600 transition resize-none font-sans"
                      />
                      
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-[10px] text-gray-500">
                          {notes.trim() ? `Длина текста: ${notes.length} символов` : "Или прикрепите текстовый файл (.txt, .md)"}
                        </span>
                        <label className="cursor-pointer bg-[#141727] hover:bg-red-950/20 hover:border-red-900/40 border border-gray-800 rounded-lg px-3 py-1.5 text-[10px] text-gray-300 transition flex items-center gap-1.5 font-mono">
                          <FileText className="w-3.5 h-3.5 text-red-500" /> Выбрать файл
                          <input 
                            type="file" 
                            accept=".txt,.md" 
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              if (file.name.endsWith(".txt") || file.name.endsWith(".md")) {
                                const reader = new FileReader();
                                reader.onload = (event) => {
                                  setNotes(event.target?.result as string || "");
                                };
                                reader.readAsText(file);
                              } else {
                                alert("Пожалуйста, загрузите файл в формате .txt или .md");
                              }
                            }}
                            className="hidden" 
                          />
                        </label>
                      </div>
                    </div>

                    {onboardingStep === 1 && (
                      <button 
                        onClick={() => {
                          if (topic.trim()) setOnboardingStep(2);
                          else alert("Введите название темы!");
                        }}
                        className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-3 px-6 rounded-xl text-sm transition"
                      >
                        ДАЛЕЕ
                      </button>
                    )}
                  </div>
                </div>

                {/* STEP 2 Card: Mic Check */}
                <div className={`bg-[#0e101b] border rounded-3xl p-6 md:p-8 transition-all duration-300 ${onboardingStep === 2 ? 'border-red-600/30' : 'border-gray-900 opacity-40'}`}>
                  <div className="flex justify-between items-center border-b border-gray-900/50 pb-4 mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-red-950/80 border border-red-900/50 flex items-center justify-center text-xs font-mono font-bold text-red-500">2</div>
                      <div>
                        <div className="text-[10px] text-red-400 font-bold uppercase tracking-wider">Шаг 2 из 2</div>
                        <h2 className="text-lg font-bold">Проверка оборудования</h2>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center py-6 space-y-4">
                    <div className={`w-20 h-20 rounded-full border flex items-center justify-center transition-all duration-500 ${micPermission === 'granted' ? 'bg-emerald-950/40 border-emerald-500/50 pulse-mic glow-green' : 'bg-red-950/30 border-red-900/50'}`}>
                      <Mic className={`w-8 h-8 ${micPermission === 'granted' ? 'text-emerald-400' : 'text-red-500'}`} />
                    </div>

                    <div className="text-center">
                      <h4 className="font-bold text-sm">
                        {micPermission === 'granted' ? 'Микрофон подключен' : 'Требуется доступ к микрофону'}
                      </h4>
                      <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">
                        {micPermission === 'granted' 
                          ? 'ИИ-экзаменатор готов принимать устные ответы.' 
                          : 'Пожалуйста, разрешите доступ к микрофону, чтобы сдавать экзамен устно.'}
                      </p>
                    </div>

                    {micPermission !== 'granted' && (
                      <button 
                        onClick={requestMicPermission}
                        className="bg-[#171b30] hover:bg-[#202542] border border-gray-800 text-xs px-4 py-2.5 rounded-xl transition"
                      >
                        Запросить разрешение
                      </button>
                    )}

                    <button 
                      onClick={() => setKeyboardMode(!keyboardMode)}
                      className="text-xs text-red-400 hover:underline flex items-center gap-1.5"
                    >
                      <Keyboard className="w-3.5 h-3.5" /> {keyboardMode ? 'Использовать микрофон' : 'Использовать клавиатуру (текст)'}
                    </button>
                  </div>

                  <div className="flex gap-4 mt-4">
                    <button 
                      onClick={() => setOnboardingStep(1)}
                      className="w-1/3 bg-[#111424] hover:bg-gray-800 text-xs font-bold py-3.5 rounded-xl text-gray-400 hover:text-white transition"
                    >
                      НАЗАД
                    </button>
                    <button 
                      onClick={handleStartExam}
                      disabled={isSubmitting}
                      className="w-2/3 bg-red-600 hover:bg-red-500 disabled:bg-red-900/40 text-white text-sm font-bold py-3.5 rounded-xl transition flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? 'ЗАГРУЗКА...' : 'НАЧАТЬ ДОПРОС'}
                    </button>
                  </div>
                </div>

              </div>

            </motion.div>
          )}

          {/* STEP EXAM: The Interrogation Area */}
          {step === 'exam' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full"
            >
              
              {/* Dialogue Main Area */}
              <div className="lg:col-span-8 bg-[#0e101b] border border-gray-900 rounded-3xl p-5 md:p-6 flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-red-950/10 blur-3xl pointer-events-none" />
                
                <div>
                  {/* Active Question Top Bar */}
                  <div className="flex justify-between items-center border-b border-gray-900 pb-4 mb-6 z-10 relative">
                    <div>
                      <span className="text-[10px] text-red-500 font-bold uppercase tracking-wider font-mono">Текущая тема</span>
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <FileText className="w-4 h-4 text-red-500" /> {topic}
                      </h3>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-sm font-mono bg-[#07080d] px-3.5 py-1.5 rounded-xl border border-gray-800 text-red-400 font-semibold flex items-center gap-1.5 shadow-inner">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                        {formatTime(timerSeconds)}
                      </div>
                      <button 
                        onClick={handleFinishExam}
                        disabled={isSubmitting}
                        className="bg-red-600/10 hover:bg-red-600 border border-red-500/20 hover:border-red-600 text-red-400 hover:text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                      >
                        Завершить
                      </button>
                    </div>
                  </div>

                  {/* Dialogue Bubble Area (Simulating Asad talking) */}
                  <div className="flex gap-4 items-start bg-[#07080d]/80 rounded-2xl p-5 border border-gray-900/60 shadow-xl relative z-10 transition">
                    <div className="w-14 h-14 rounded-2xl overflow-hidden border border-red-900/30 flex-shrink-0 glow-red">
                      <img src={asadAvatar} alt="Asad Portrait" className="w-full h-full object-cover" />
                    </div>
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-gray-200">Асад Экзаменатор</span>
                          <span className={`w-2 h-2 rounded-full ${isAsadSpeaking ? 'bg-green-500 animate-pulse' : 'bg-red-500 animate-ping'}`} />
                          <span className="text-[10px] text-gray-500 font-mono">
                            {isAsadSpeaking ? 'ОЗВУЧКА АКТИВНА' : 'СЛУШАЕТ ВАС'}
                          </span>
                        </div>
                        {activeQuestion && (
                          <button 
                            onClick={() => speakAsad(activeQuestion)}
                            className="bg-red-600/10 hover:bg-red-600 border border-red-500/20 hover:border-red-600 text-red-400 hover:text-white text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer"
                            title="Озвучить вопрос заново"
                          >
                            <Volume2 className="w-3.5 h-3.5" /> ОЗВУЧИТЬ ВОПРОС
                          </button>
                        )}
                      </div>
                      <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-line mt-1 font-sans">
                        {activeQuestion || "Задаю каверзный вопрос по теме..."}
                      </p>
                    </div>
                  </div>
                  
                  {/* Glowing Listen Notification */}
                  <div className="mt-4 flex items-center gap-2 text-xs font-mono pl-1 relative z-10">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                    <span className="text-emerald-400 font-bold uppercase tracking-wide">● СЛУШАЕТ ВАШ ОТВЕТ...</span>
                  </div>

                </div>

                {/* Input Area / Recording Waves / Textbox */}
                <div className="mt-8 bg-[#07080d] rounded-2xl p-5 border border-gray-900 relative z-10">
                  
                  {!keyboardMode ? (
                    // Voice mode visualizer
                    <div className="flex flex-col items-center py-4 space-y-6">
                      
                      {/* Animated Sine Wave Visualizer */}
                      <div className="w-full h-16 flex items-center justify-center overflow-hidden relative">
                        <div className="absolute inset-0 flex items-center justify-center opacity-40">
                          {/* Fake or Dynamic SVG Line waves based on audioLevel */}
                          <svg className="w-full h-12" viewBox="0 0 400 100" preserveAspectRatio="none">
                            <path 
                              d={`M 0 50 Q 50 ${50 - audioLevel * 0.4} 100 50 T 200 50 T 300 50 T 400 50`}
                              fill="none" 
                              stroke="#ef4444" 
                              strokeWidth="2" 
                              className="transition-all duration-75"
                            />
                            <path 
                              d={`M 0 50 Q 50 ${50 + audioLevel * 0.2} 100 50 T 200 50 T 300 50 T 400 50`}
                              fill="none" 
                              stroke="#f87171" 
                              strokeWidth="1" 
                              className="opacity-60 transition-all duration-75"
                            />
                          </svg>
                        </div>
                        
                        <div className="relative z-10 text-xs font-mono text-gray-500 tracking-wider">
                          {isRecording ? "ГОВОРИТЕ..." : "МИКРОФОН ВЫКЛЮЧЕН"}
                        </div>
                      </div>

                      <div className="flex flex-col items-center space-y-3">
                        <button 
                          onClick={toggleRecording}
                          className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 ${isRecording ? 'bg-emerald-600 hover:bg-emerald-500 glow-green' : 'bg-red-600 hover:bg-red-500 glow-red'}`}
                          title={isRecording ? "Остановить запись" : "Начать отвечать голосом"}
                        >
                          <Mic className="w-7 h-7 text-white" />
                        </button>
                        
                        <div className="text-center">
                          <p className="text-xs font-bold text-gray-300">
                            {isRecording ? "Идет запись ответа. Нажмите кнопку повторно для фиксации." : "Нажмите для записи устного ответа"}
                          </p>
                          <p className="text-[10px] text-gray-500 mt-1">
                            {isRecording ? "Детектор пауз и паразитов активен." : "Говорите четко и по существу."}
                          </p>
                        </div>
                      </div>

                      {/* Real-time transcribed text display */}
                      {transcript && (
                        <div className="w-full bg-[#111424]/60 p-4 rounded-xl border border-gray-800/80 text-xs text-gray-300 italic text-center max-h-24 overflow-y-auto">
                          "{transcript}"
                        </div>
                      )}

                      {/* Actions for transcribed answer */}
                      <div className="flex gap-4 w-full">
                        <button 
                          onClick={() => {
                            setTextAnswer(transcript);
                            setKeyboardMode(true);
                          }}
                          className="w-1/2 bg-[#121526] hover:bg-[#1a1f38] text-gray-400 hover:text-white text-xs font-semibold py-3 rounded-xl transition border border-gray-800/80 cursor-pointer"
                        >
                          Переключить на текст
                        </button>
                        {isRecording ? (
                          <button 
                            onClick={stopAndSubmitVoice}
                            disabled={isSubmitting}
                            className="w-1/2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-950/40 disabled:text-gray-500 text-white text-xs font-bold py-3 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-950/50"
                          >
                            <span className="w-2 h-2 rounded-full bg-white animate-ping"></span>
                            {isSubmitting ? 'ОБРАБОТКА...' : '■ ЗАВЕРШИТЬ И ОТПРАВИТЬ'}
                          </button>
                        ) : (
                          <button 
                            onClick={() => submitAnswer(transcript)}
                            disabled={isSubmitting || !transcript.trim()}
                            className="w-1/2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-950/40 disabled:text-gray-500 text-white text-xs font-bold py-3 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
                          >
                            {isSubmitting ? 'АНАЛИЗ...' : '✓ ОТПРАВИТЬ ОТВЕТ'}
                          </button>
                        )}
                      </div>

                    </div>
                  ) : (
                    // Keyboard Text Mode
                    <div className="space-y-4">
                      <textarea 
                        rows={3} 
                        placeholder="Введите ваш академический и развернутый ответ здесь..."
                        value={textAnswer}
                        onChange={(e) => setTextAnswer(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            submitAnswer(textAnswer);
                          }
                        }}
                        className="w-full bg-[#0e101b] border border-gray-800 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-red-500 text-gray-200 placeholder-gray-600 transition resize-none"
                      />
                      <div className="flex justify-between items-center">
                        <button 
                          onClick={() => setKeyboardMode(false)}
                          className="text-xs text-gray-500 hover:text-gray-300 hover:underline flex items-center gap-1"
                        >
                          ← Назад к голосу
                        </button>
                        <button 
                          onClick={() => submitAnswer(textAnswer)}
                          disabled={isSubmitting || !textAnswer.trim()}
                          className="bg-red-600 hover:bg-red-500 disabled:bg-red-950/40 disabled:text-gray-500 text-white text-xs font-bold px-6 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" /> {isSubmitting ? 'ОЦЕНКА...' : 'Отправить'}
                        </button>
                      </div>
                    </div>
                  )}

                </div>

              </div>

              {/* Real-time statistics right sidebar */}
              <div className="lg:col-span-4 bg-[#0e101b] border border-gray-900 rounded-3xl p-6 flex flex-col justify-between">
                <div>
                  <div className="border-b border-gray-900 pb-3 mb-6 flex justify-between items-center">
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">Анализ речи</h4>
                    <span className="text-[10px] bg-red-950/40 text-red-400 px-2.5 py-1 rounded-md border border-red-900/30 font-mono">LIVE</span>
                  </div>

                  <div className="space-y-6">
                    {/* Pause counter */}
                    <div className="flex justify-between items-center bg-[#07080d] p-4 rounded-2xl border border-gray-900/50 shadow-inner">
                      <div>
                        <span className="text-xs text-gray-400 font-semibold block">Паузы</span>
                        <span className="text-[10px] text-gray-500 block font-mono">длинные тишины (&gt;4.5с)</span>
                      </div>
                      <span className={`text-2xl font-black font-mono ${stats.pauses > 0 ? 'text-red-500 animate-pulse' : 'text-gray-500'}`}>
                        {stats.pauses}
                      </span>
                    </div>

                    {/* Fillers counter */}
                    <div className="flex justify-between items-center bg-[#07080d] p-4 rounded-2xl border border-gray-900/50 shadow-inner">
                      <div>
                        <span className="text-xs text-gray-400 font-semibold block">Слова-паразиты</span>
                        <span className="text-[10px] text-gray-500 block font-mono">"ну", "типа", "как бы"</span>
                      </div>
                      <span className={`text-2xl font-black font-mono ${stats.fillers > 0 ? 'text-red-500 animate-pulse' : 'text-gray-500'}`}>
                        {stats.fillers}
                      </span>
                    </div>

                    {/* Confidence percentage */}
                    <div className="flex justify-between items-center bg-[#07080d] p-4 rounded-2xl border border-gray-900/50 shadow-inner">
                      <div>
                        <span className="text-xs text-gray-400 font-semibold block">Уверенность речи</span>
                        <span className="text-[10px] text-gray-500 block font-mono">рассчитываемый индекс</span>
                      </div>
                      <span className={`text-2xl font-black font-mono ${stats.confidence < 50 ? 'text-red-500' : stats.confidence < 80 ? 'text-yellow-500' : 'text-emerald-500'}`}>
                        {stats.confidence}%
                      </span>
                    </div>

                    {/* Logic error count */}
                    <div className="flex justify-between items-center bg-[#07080d] p-4 rounded-2xl border border-gray-900/50 shadow-inner">
                      <div>
                        <span className="text-xs text-gray-400 font-semibold block">Логические ошибки</span>
                        <span className="text-[10px] text-gray-500 block font-mono">предварительный ИИ-контроль</span>
                      </div>
                      <span className={`text-2xl font-black font-mono ${stats.errors > 0 ? 'text-red-500 animate-pulse' : 'text-gray-500'}`}>
                        {stats.errors}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-8 bg-[#0c2415]/10 border border-emerald-950/50 rounded-2xl p-4 flex items-start gap-3">
                  <Activity className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-bold text-emerald-400">Система анализа активна</div>
                    <p className="text-[10px] text-gray-500 mt-0.5 leading-relaxed">
                      Экзаменатор придирчиво слушает структуру и смысл. Любые пробелы будут отражены в вердикте.
                    </p>
                  </div>
                </div>
              </div>

            </motion.div>
          )}

          {/* STEP VERDICT: The Verdict Stamp Card */}
          {step === 'verdict' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-xl mx-auto w-full bg-[#0e101b] border border-gray-900 rounded-3xl p-6 md:p-8 space-y-8 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 via-yellow-500 to-emerald-500" />
              
              <div className="text-center space-y-2">
                <span className="text-[10px] text-red-500 font-black tracking-widest uppercase font-mono bg-red-950/20 px-3 py-1 rounded-full border border-red-900/20">
                  Экзамен завершен
                </span>
                <h2 className="text-3xl md:text-4xl font-black tracking-tighter">ИТОГОВЫЙ ВЕРДИКТ</h2>
              </div>

              {/* ROUGH RUSTIC VERDICT STAMP */}
              <div className="flex justify-center my-8 relative">
                <div className="absolute inset-0 bg-red-600/5 blur-2xl rounded-full" />
                <motion.div 
                  initial={{ scale: 0.5, rotate: -25, opacity: 0 }}
                  animate={{ scale: 1, rotate: -5, opacity: 1 }}
                  transition={{ type: "spring", damping: 12, delay: 0.2 }}
                  className={`stamp-font border-4 px-10 py-4 rounded-2xl tracking-widest text-3xl font-black uppercase shadow-lg transform -rotate-6 z-10 ${
                    verdict?.verdict === 'НЕ СДАНО' 
                      ? 'border-red-600 text-red-600 bg-red-950/10 shadow-red-900/10' 
                      : verdict?.verdict === 'ПОКА ЖИВИ' 
                      ? 'border-amber-500 text-amber-500 bg-amber-950/10 shadow-amber-900/10' 
                      : 'border-emerald-500 text-emerald-500 bg-emerald-950/10 shadow-emerald-900/10'
                  }`}
                >
                  {verdict?.verdict || "ОЦЕНКА"}
                </motion.div>
              </div>

              {/* Verdict brief description */}
              <div className="text-center px-4">
                <p className="text-gray-300 font-medium text-sm leading-relaxed">
                  {verdict?.description || "Асад сформировал решение на основе ваших ответов."}
                </p>
              </div>

              {/* Specific logical holes list */}
              <div className="bg-[#07080d] rounded-2xl p-5 border border-gray-900 space-y-4">
                <div className="flex justify-between items-center border-b border-gray-900 pb-3">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">
                    Ключевые упущения и дыры ({verdict?.holes.length || 0} из 5)
                  </h4>
                  <HelpCircle className="w-4 h-4 text-gray-600" />
                </div>
                
                <ul className="space-y-3">
                  {verdict?.holes.map((hole, index) => (
                    <li key={index} className="flex items-start gap-3 text-xs leading-relaxed text-gray-400">
                      <span className="w-5 h-5 rounded-full bg-red-950/80 border border-red-900/50 text-red-400 font-mono text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                        {index + 1}
                      </span>
                      <span>{hole}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Dialogue History rundown toggle */}
              <div className="flex flex-col gap-3">
                <button 
                  onClick={() => setIsAnalysisModalOpen(true)}
                  className="w-full bg-[#121526] hover:bg-[#1b1f38] border border-gray-800 text-gray-300 hover:text-white font-semibold py-3.5 rounded-xl text-xs transition flex items-center justify-center gap-1.5"
                >
                  🔍 ПОДРОБНЫЙ РАЗБОР ДИАЛОГА →
                </button>
                <button 
                  onClick={restartExam}
                  className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-4 rounded-xl text-xs transition flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" /> ПРОЙТИ ЕЩЁ РАЗ
                </button>
              </div>

            </motion.div>
          )}

        </AnimatePresence>

      </main>

      {/* DETAILED ANALYSIS BOTTOM DRAWER / MODAL */}
      <AnimatePresence>
        {isAnalysisModalOpen && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-[#0e101b] border border-gray-900 rounded-3xl max-w-2xl w-full max-h-[80vh] flex flex-col justify-between overflow-hidden"
            >
              <div className="p-6 border-b border-gray-900 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-red-500" />
                  <h3 className="font-bold text-base">Подробный разбор и стенограмма</h3>
                </div>
                <button 
                  onClick={() => setIsAnalysisModalOpen(false)}
                  className="p-1 rounded-lg hover:bg-gray-800 transition"
                >
                  <X className="w-5 h-5 text-gray-400 hover:text-white" />
                </button>
              </div>

              <div className="p-6 overflow-y-auto space-y-4 flex-1">
                {dialogueHistory.length === 0 ? (
                  <p className="text-gray-500 text-center text-xs">История диалога пуста.</p>
                ) : (
                  dialogueHistory.map((msg, i) => (
                    <div 
                      key={i} 
                      className={`flex gap-3 items-start p-4 rounded-xl border ${
                        msg.role === 'assistant' 
                          ? 'bg-[#07080d]/60 border-gray-900' 
                          : 'bg-red-950/5 border-red-900/10'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg font-bold font-mono text-[10px] flex items-center justify-center flex-shrink-0 ${
                        msg.role === 'assistant' ? 'bg-red-950 text-red-500' : 'bg-gray-800 text-gray-300'
                      }`}>
                        {msg.role === 'assistant' ? 'А' : 'Я'}
                      </div>
                      <div className="space-y-0.5">
                        <div className="text-[10px] font-bold text-gray-500 uppercase">
                          {msg.role === 'assistant' ? 'Асад Экзаменатор' : 'Студент'}
                        </div>
                        <p className="text-xs text-gray-300 leading-relaxed whitespace-pre-line">{msg.content}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="p-5 border-t border-gray-900 bg-[#07080d]/40 flex justify-end">
                <button 
                  onClick={() => setIsAnalysisModalOpen(false)}
                  className="bg-red-600 hover:bg-red-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition"
                >
                  Закрыть разбор
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {apiError && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#020204]/90 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0b0c16] border border-red-500/30 rounded-3xl p-6 md:p-8 max-w-lg w-full relative overflow-hidden shadow-2xl glow-red"
            >
              {/* Background red glow */}
              <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-red-950/25 blur-3xl pointer-events-none" />
              
              <div className="flex items-start gap-4">
                <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-3 text-red-500 shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-100 font-sans">Ошибка работы ИИ</h3>
                  <p className="text-xs text-gray-400 font-mono mt-1 uppercase tracking-wider">Сбой / Ограничение лимитов</p>
                </div>
              </div>

              <div className="mt-4 bg-[#05060b] border border-gray-900 rounded-2xl p-4">
                <p className="text-gray-300 text-xs leading-relaxed font-sans whitespace-pre-line">
                  {apiError}
                </p>
              </div>

              {/* Action Guides */}
              <div className="mt-5 space-y-3">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wide font-sans">Что можно сделать?</h4>
                <ul className="text-[11px] text-gray-400 space-y-2 font-sans list-disc list-inside">
                  <li>
                    <strong className="text-red-400">Настройки API Ключа</strong>: Нажмите на <strong className="text-gray-200">иконку шестерёнки в правом верхнем углу</strong> экрана AI Studio, чтобы ввести свой персональный API Ключ Gemini. Это полностью снимет любые лимиты!
                  </li>
                  <li>
                    <strong className="text-red-400">Подождите 1 минуту</strong>: Лимиты бесплатных запросов обычно сбрасываются автоматически в течение одной-двух минут.
                  </li>
                  <li>
                    <strong className="text-red-400">Повторить попытку</strong>: Попробуйте нажать кнопку ещё раз — наша система автоматически переключит запрос на запасную модель.
                  </li>
                </ul>
              </div>

              <div className="mt-6 flex justify-end">
                <button 
                  onClick={() => setApiError(null)}
                  className="bg-red-600 hover:bg-red-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition font-mono flex items-center gap-2 cursor-pointer"
                >
                  <X className="w-4 h-4" /> ЗАКРЫТЬ
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TRIPLE CAPABILITY VALUE PROP FOOTER */}
      <footer className="border-t border-gray-950 bg-[#06070a]/90 py-5 px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-center gap-6 md:gap-10 text-xs text-gray-500">
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-red-600" />
            <span>Только голос. Audio-to-Audio</span>
          </div>
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-red-600" />
            <span>Строгий ИИ-экзаменатор задаёт каверзные вопросы</span>
          </div>
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-red-600" />
            <span>Находит логические дыры и слабые места</span>
          </div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-red-600" />
            <span>Анализирует речь: паузы, уверенность, ошибки</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-red-600" />
            <span>Готовься жёстко. Сдай уверенно.</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
